csnews
======

News module for Django